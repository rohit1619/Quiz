<!DOCTYPE html>
<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;700&family=Space+Grotesk:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<header>
	<div>
		<p>PHP QUIZER</p>
	</div>
</header>
<main>
	<div class="menu">

		<a href="main.php" class="button">Take Quiz</a>
		<a href="add.php" class="button">Add question</a>
	</div>
</main>
<footer>
	<div class="container">
		Copyright &copy; SARScoders
	</div>
</footer>
</body>
</html>