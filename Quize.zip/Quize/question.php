<?Php
$host_name = "localhost";
$database = "quize"; // Change your database name
$username = "root";         // Your database user id 
$password = "";          // Your password

//////// Do not Edit below /////////
try {
$dbo = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
} catch (PDOException $e) {
print "Error!: " . $e->getMessage() . "<br/>";
die();
}
	function totalquestion()
{
	global $dbo;
	$sql = "SELECT count(*) AS total FROM `question`";	
$resultset = $dbo->query($sql); 
$result=$resultset->fetch(PDO::FETCH_ASSOC);
return $result['total']; 
}

function questions($q_no){
	global $dbo;
	$sql = "SELECT * FROM `question` where `question_no`=$q_no";	
    $resultset = $dbo->query($sql); 
    $result=$resultset->fetchAll(PDO::FETCH_OBJ);
    return $result;
}
function answer($q_no){
	global $dbo;
	$sql = "SELECT * FROM `answers` where `question_no`=$q_no";	
    $resultset = $dbo->query($sql); 
    $result=$resultset->fetchAll(PDO::FETCH_OBJ);
    return $result;
}

if(isset($_POST['sub_ans']))
{
	$ans=$_POST['ans'];
	$answer=$_POST['answer'];
	$data=intval($ans)+intval($answer);
}


$answer=answer($_REQUEST['n']);
$question=questions($_REQUEST['n']);
$total=totalquestion();
?>


<!DOCTYPE html>
<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;700&family=Space+Grotesk:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<header>
	<div>
		<p>PHP QUIZER</p>
	</div>
</header>
<main>
	<div class="menu">
		<?php
		if($total >= $_REQUEST['n'])
		{
		?>
<h3>Question <?=$_REQUEST['n']?> Of <?=$total?></h3>
<h2>
<?php
foreach($question as $value)
{
	echo $value->question;
}
?>
</h2>
		
			<form method="post" action="question.php?n=<?=$_REQUEST['n']+1?>">
				<p>
			<?php
foreach($answer as $value)
{
	 ?>
	 <input type="radio" name="ans" required="required" value="<?=$value->is_correct;?>"><?=$value->answer;?><br>
<?php } ?>
</p>
<?php
if(isset($data))
{
?>
<input type="hidden" name="answer" value="<?=$data?>">
<?php
}
else{
?>
	<input type="hidden" name="answer" value="0">
<?php
}
?>
<input type="submit" name="sub_ans" class="button">
</form>
<?php } 
else{
?>
<h3>You get <?=$data?> out of <?=$total?></h3>
<a href="index.php" class="button">Back To Home</a>
<?php
}
?>
	</div>
</main>
<footer>
	<div class="container">
		Copyright &copy; SARScoders
	</div>
</footer>
</body>
</html>