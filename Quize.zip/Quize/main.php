<?Php
$host_name = "localhost";
$database = "quize"; // Change your database name
$username = "root";         // Your database user id 
$password = "";          // Your password

//////// Do not Edit below /////////
try {
$dbo = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
} catch (PDOException $e) {
print "Error!: " . $e->getMessage() . "<br/>";
die();
}
	function totalquestion()
{
	global $dbo;
	$sql = "SELECT count(*) AS total FROM `question`";	
$resultset = $dbo->query($sql); 
$result=$resultset->fetch(PDO::FETCH_ASSOC);
return $result['total']; 
}
$total=totalquestion();
?>


<!DOCTYPE html>
<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;700&family=Space+Grotesk:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<header>
	<div>
		<p>PHP QUIZER</p>
	</div>
</header>

<mian>
	<div class="menu">
		<h2>Test Your PHP Knowledge</h2>
		<p>
			This is a multiple choise quiz to test your PHP Knowledge.
		</p>
		<ul>
			<li><strong>Number Of Question:</strong><?=$total?></li>
			<li><strong>Type:</strong>Multiple Chouise</li>
		</ul>
		<a href="question.php?n=1" class="button">Start Quiz</a>
	</div>
</mian>
<footer>
	<div class="container">
		Copyright &copy; SARScoders
	</div>
</footer>
</body>
</html>