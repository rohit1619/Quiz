<?Php
$host_name = "localhost";
$database = "quize"; // Change your database name
$username = "root";         // Your database user id 
$password = "";          // Your password

//////// Do not Edit below /////////
try {
$dbo = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
} catch (PDOException $e) {
print "Error!: " . $e->getMessage() . "<br/>";
die();
}

//Insert Question
if(isset($_POST['submit']) AND $_POST['submit']=="submit")
	{
		$question=$_POST['question'];
		$qution_no=$_POST['question_number'];
		$answer=$_POST['answer'];
		$choise=array();
		$choise[1]=$_POST['choise1'];
		$choise[2]=$_POST['choise2'];
		$choise[3]=$_POST['choise3'];
		$choise[4]=$_POST['choise4'];
		$sql=$dbo->prepare("insert into `question` (`question`,`question_no`) values(:x,:y)");
		$sql->bindParam(':x',$question);
		$sql->bindParam(':y',$qution_no);


		if($sql->execute()){
		foreach($choise as $option=>$value){
		if($value !="")
		{
			if($answer == $option){
			$is_correct=1;
		}
		else{
		$is_correct=0;
	}
		}
		$sql2=$dbo->prepare("insert into `answers` (`answer`,`question_no`,`is_correct`) values(:a,:b,:c)");
		$sql2->bindParam(':a',$value);
		$sql2->bindParam(':b',$qution_no);
		$sql2->bindParam(':c',$is_correct);
if($sql2->execute()){
	header("Location:add.php?msg=Question Added successfuly");
}
	}

		}
		else{
		echo " Not able to add data please contact Admin <br>";
		print_r($sql->errorInfo()); // Getting Error info
		}
	}

	function totalquestion()
{
	global $dbo;
	$sql = "SELECT count(*) AS total FROM `question`";	
$resultset = $dbo->query($sql); 
$result=$resultset->fetch(PDO::FETCH_ASSOC);
return $result['total']; 
}
$question_number=totalquestion()+1;
?>

<!DOCTYPE html>
<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;700&family=Space+Grotesk:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<header style="margin-bottom: 10px;">
	<div>
		<p>PHP QUIZER</p>
	</div>
</header>
<main>
	<div class="body_container">
		<?php
		if(isset($_REQUEST['msg']))
		{
		?>
		<div style="background-color: green; color: white; padding: 0px 10%; font-size: 14px;
	 font-family: 'Space Grotesk', sans-serif;">
		<p><?=$_REQUEST['msg']?></p>
	</div>
		<?php }?>
		<h2>Add A Question</h2>
		<form method="post" action="add.php">
			<p>
			<label>Question Number: </label><input type="number" name="question_number" value="<?=$question_number?>" readonly="readonly" style="width: 30px; height: 25px; border-radius: 5px; border: 2px solid black; margin-bottom: -8px;">
			</p>
			<p>
				<STRONG>Question Text:</STRONG><br>
				<input type="text" name="question" required="required" style="width: 600px; height: 20px; border-radius: 5px; border: 1px solid black;">
			</p>
			<p>
				<label>Choise 1:</label>
				<input type="text" name="choise1" required="required" style="width: 300px; height: 20px; border-radius: 5px; border: 1px solid black;">
			</p>
			<p>
				<label>Choise 2:</label>
				<input type="text" name="choise2" required="required" style="width: 300px; height: 20px; border-radius: 5px; border: 1px solid black;">
			</p>
			<p>
				<label>Choise 3:</label>
				<input type="text" name="choise3" required="required" style="width: 300px; height: 20px; border-radius: 5px; border: 1px solid black;">
			</p>
			<p>
				<label>Choise 4:</label>
				<input type="text" name="choise4" required="required" style="width: 300px; height: 20px; border-radius: 5px; border: 1px solid black;">
			</p>
			<p>
				<label>Correct Option Number:</label>
				<input type="number" name="answer" required="required" style="width: 30px; height: 25px; border-radius: 5px; border: 2px solid black;">
			</p>
			<input type="submit" name="submit" value="submit" style="background-color:#4CAF50; border:none; color: white; padding: 5px 30px; font-size: 22px; width: 150px; margin:20px; font-family: 'Space Grotesk', sans-serif;">
		</form>
	</div>
</main>
<footer>
	<div class="container">
		Copyright &copy; SARScoders
	</div>
</footer>
</body>
</html>